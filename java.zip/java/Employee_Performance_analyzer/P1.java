import java.util.Scanner;

public class P1{
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int highest = 0;
        int lowest = 100;

        for (int i = 1; i <= 6; i++) {
            System.out.println("Enter your Score:");
            int score = sc.nextInt();

            if (score >= 90) {
                System.out.println("Excellent");
            } else if (score >= 75) {
                System.out.println("Good");
            } else if (score >= 50) {
                System.out.println("Average");
            } else {
                System.out.println("Poor");
            }

            if (score > highest) {
                highest = score;
            }
            if (score < lowest) {
                lowest = score;
            }
        }

        System.out.println("Highest score:" + highest);
        System.out.println("lowest score:" + lowest);

        sc.close();
    }
}