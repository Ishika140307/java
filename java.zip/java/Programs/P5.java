//Take 10 numbers print only positive - continue

import java.util.Scanner;

public class P5 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        for (int i = 1; i <= 10; i++) {
            System.out.print("Enter number " + i + ": ");
            int num = sc.nextInt();
            if (num <= 0) {
                continue;
            }
            System.out.println("Positive: " + num);
        }
        sc.close();
    }
}