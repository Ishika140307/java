//Take 10 numbers, if user enter 50 stop - break

import java.util.Scanner;

public class P4 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        for (int i = 1; i <= 10; i++) {
            System.out.print("Enter number " + i + ": ");
            int num = sc.nextInt();
            if (num == 50) {
                System.out.println("50 entered, stopping...");
                break;
            }
        }
        sc.close();
    }
}