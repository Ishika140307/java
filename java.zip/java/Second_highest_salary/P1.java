import java.util.Scanner;

public class P1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        int h = 0;
        int s_h = 0;

        for (int i = 1; i <= 5; i++) {
            System.out.println("Enter your salary...");
            int salary = sc.nextInt();

            if (salary > h) {
                s_h = h;
                h = salary;
            } 
            else if ((salary > s_h) && (salary != h)) {
                s_h = salary;
            }
        }
        
        System.out.println("Highest Salary:" + h);
        System.out.println("Second highest Salary:" + s_h);

        sc.close();
    }
}