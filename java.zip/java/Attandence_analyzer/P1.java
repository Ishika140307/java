import java.util.Scanner;

public class P1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Enter total days :");
        while (!sc.hasNextInt()) {
            System.out.println("Please enter a valid number!");
            sc.next(); // discard invalid input
        }
        int total_days = sc.nextInt();

        int present_days = 0;
        int absent_days = 0;

        for (int i = 1; i <= total_days; i++) {
            System.out.println("Day " + i + " - enter 1 for present and 0 for absent:");
            
            while (!sc.hasNextInt()) {
                System.out.println("Invalid input! Enter 1 or 0 only:");
                sc.next();
            }
            int attendance = sc.nextInt();

            if (attendance == 1) {
                present_days++;
            } else if (attendance == 0) {
                absent_days++;
            } else {
                System.out.println("Invalid input - counted as absent");
                absent_days++;
            }
        }

        float attendance_percentage = (present_days * 100.0f) / total_days;

        System.out.println("present days :" + present_days);
        System.out.println("absent days:" + absent_days);
        System.out.println("attendance percentage :" + attendance_percentage);

        sc.close();
    }
}