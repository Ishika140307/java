public class P1 {
    public static void main(String[] args) {
        for (int i = 2; i <= 51; i++) {
            int prime = 1;
            for (int j = 2; j < i; j++) {
                if (i % j == 0) {
                    prime = 0;
                    break;
                }
            }
            if (prime == 1) {
                System.out.println(i);
            }
        }
    }
}