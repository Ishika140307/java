import java.util.Scanner;

public class P1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int low = 0;
        int medium = 0;
        int high = 0;

        for (int i = 1; i <= 10; i++) {
            System.out.println("Enter the amount:");
            int amount = sc.nextInt();

            if (amount < 10000) {
                System.out.println("Low Risk");
                low = low + 1;
            } else if (amount <= 50000) {
                System.out.println("Medium Risk");
                medium = medium + 1;
            } else {
                System.out.println("High Risk");
                high = high + 1;
            }
        }

        System.out.println("Low Risk transactions:" + low);
        System.out.println("High Risk transactions:" + high);
        System.out.println("Medium Risk transactions:" + medium);

        sc.close();
    }
}