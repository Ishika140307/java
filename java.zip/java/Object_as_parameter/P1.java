class Student {
    String name;
    int marks;
}

class StudFactory {
    Student createStud() {
        Student s = new Student();
        s.name = "Ishika";
        s.marks = 95;
        return s;
    }
}

public class P1 {
    public static void main(String[] args) {
        StudFactory f1 = new StudFactory();
        Student s1 = f1.createStud();

        System.out.println("The name is " + s1.name);
        System.out.println("The marks are " + s1.marks);
    }
}