class BankAccount {
    String accountHoldName;
    double balance;

    void calculate(BankAccount receiver, double amount) {
        if (balance >= amount) {
            balance = balance - amount;
            receiver.balance = receiver.balance + amount;
        }
    }
    
    void transferTo(BankAccount receiver, double amount) {
        calculate(receiver, amount);
    }
}

public class P2{
    public static void main(String[] args) {
        BankAccount a1 = new BankAccount();
        BankAccount a2 = new BankAccount();

        a1.balance = 20000;
        a2.balance = 15000;

        a1.transferTo(a2, 5000);

        System.out.println("a1 balance = " + a1.balance);
        System.out.println("a2 balance = " + a2.balance);
    }
}