class Shop {
    String component;
    double price;
}

public class P2 {
    public static void main(String[] args) {
        Shop p1 = new Shop();
        p1.component = "laptop";
        p1.price = 50000;

        Shop p2 = p1; // Object reference assignment

        p2.price = 45000;

        System.out.println(p1.price);
        System.out.println(p2.price);
    }
}