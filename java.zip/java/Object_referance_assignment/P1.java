class Student {
    String name;
    int age;
}

public class P1 {
    public static void main(String[] args) {
        Student s1 = new Student();
        Student s2 = s1; 

        s1.name = "Ishika";
        System.out.println("The name is " + s1.name);
        System.out.println(s2.name);
    }
}