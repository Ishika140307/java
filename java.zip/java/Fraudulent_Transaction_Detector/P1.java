import java.util.Scanner;

public class P1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int suspicious_count = 0;
        float total_value = 0;

        for (int i = 1; i <= 3; i++) {
            System.out.println("Enter the amount:");
            float amount = sc.nextFloat();

            if (amount > 100000) {
                System.out.println("Suspicious Transaction");
                suspicious_count += 1;
            } else {
                System.out.println("Normal Transaction");
            }
            total_value += amount;
        }

        System.out.println("Suspicious Transactions:" + suspicious_count);
        System.out.println("Total value :" + total_value);

        sc.close();
    }
}