import java.util.Scanner;

public class P1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int successful = 0;
        int rejected = 0;

        for (int i = 1; i <= 10; i++) {
            System.out.println("Enter the amount:");
            int amount = sc.nextInt();

            if (amount <= 0) {
                System.out.println("Rejected : Invalid Amount");
                rejected += 1;
            } else if (amount % 5 != 0) {
                System.out.println("Rejected : Amount must be a multiple of 5");
                rejected += 1;
            } else if (amount > 20000) {
                System.out.println("Rejected : withdrawal limit is 20,000");
                rejected += 1;
            } else {
                System.out.println("Successful Withdrawal");
                successful += 1;
            }
        }

        System.out.println("Successful Transactions:" + successful);
        System.out.println("Rejected Transactions:" + rejected);

        sc.close();
    }
}