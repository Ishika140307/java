
class Student {
    private String name;
    private int marks;

    void setName(String name) {
        this.name = name;
    }

    void setMarks(int marks) {
        if (marks >= 0 && marks <= 100) {
            this.marks = marks;
        } else {
            System.out.println("Invalid marks");
        }
    }

    void getName() {
        System.out.println("Student Name: " + name);
    }

    void getMarks() {
        System.out.println("Student Marks: " + marks);
    }
}

public class Main {
    public static void main(String[] args) {
        Student s1 = new Student();

        s1.setName("Ishika");
        s1.setMarks(85);

        s1.getName();
        s1.getMarks();
    }
}
