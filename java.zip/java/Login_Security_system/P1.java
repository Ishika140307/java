import java.util.Scanner;

public class P1{
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        String correct_password = "Ishika123";

        for (int i = 1; i <= 3; i++) {
            System.out.println("Enter the password:");
            String password = sc.next();

            if (password.equals(correct_password)) {
                System.out.println("Login Successful");
                break;
            } else {
                System.out.println("Incorrect password");
                if (i == 3) {
                    System.out.println("Account locked");
                }
            }
        }
        sc.close();
    }
}